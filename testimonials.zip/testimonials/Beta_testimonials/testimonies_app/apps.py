from django.apps import AppConfig


class TestimoniesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'testimonies_app'
