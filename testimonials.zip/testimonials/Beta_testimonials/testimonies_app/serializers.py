from rest_framework import serializers
from .models import testimonial_model


# declaring my serializer here

class testimonial_model_serializer(serializers.ModelSerializer):
    account_user = serializers.CharField(max_length=200)
    user_testimonial = serializers.CharField(max_length=300)
    image = serializers.CharField(max_length=300)

    class Meta:
        model = testimonial_model
        fields = ('__all__')