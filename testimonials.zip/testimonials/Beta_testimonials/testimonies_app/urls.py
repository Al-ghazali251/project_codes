from django.urls import path
from .views import testimonialViews,testimonialViewsdel,testimonialViewsput,testimonialViewsget

urlpatterns = [
    path('testimonials', testimonialViews.as_view()),
    path('testimonials/del/<int:id>', testimonialViewsdel.as_view()),
    path('testimonials/patch/<int:id>', testimonialViewsput.as_view()),
    path('testimonials/get/<int:id>', testimonialViewsget.as_view()),

    


]
