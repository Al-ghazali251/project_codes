from django.shortcuts import render

# Create your views here.
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import testimonial_model_serializer
from .models import testimonial_model
from django.shortcuts import get_object_or_404


class testimonialViews(APIView):
    def post(self, request):
        serializer = testimonial_model_serializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response({"status": "error", "data": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


class testimonialViewsget(APIView):    
    def get(self, request, id=None):
        if id:
            item = testimonial_model.objects.get(id=id)
            serializer = testimonial_model_serializer(item)
            return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)

        items = testimonial_model.objects.all()
        serializer = testimonial_model_serializer(items, many=True)
        return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)


class testimonialViewsput(APIView):
        def put(self, request, id=None):
            item = testimonial_model.objects.get(id=id)
            serializer = testimonial_model_serializer(item, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response({"status": "success", "data": serializer.data})
            else:
                return Response({"status": "error", "data": serializer.errors})

class testimonialViewsdel(APIView):
    def delete(self, request, id=None):
            item = get_object_or_404(testimonial_model, id=id)
            item.delete()
            return Response({"status": "success", "data": "Item Deleted"})
        

        