from django.db import models

# Create your models here.

class testimonial_model(models.Model):
    account_user = models.CharField(max_length=200)
    user_testimonial = models.CharField(max_length=200)
    image = models.CharField(max_length=200)

    